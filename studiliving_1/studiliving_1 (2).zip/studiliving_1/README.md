# Studiliving – WG- & Wohnungsplattform

Eine verteilte Webanwendung für Studierende, um WG-Zimmer zu finden oder anzubieten.

## Features
- Nutzerregistrierung & Login
- CRUD für Wohnungsanzeigen
- Geolocation via OpenCage API
- Frontend & Backend getrennt
